%Gerson Steven Majano Guandique 00064420 seccion 01
%Noe Bladimir Alas Moscoso 00262020 seccion 01

%base_de_conocimiento

%lugares parques
lugares(parque_daniel_hernandez).
lugares(parque_san_martin).
lugares(parque_deportivo_el_cafetalon).

%lugares centros de estudio
lugares(colegio_santa_cecilia).
lugares(escuela_monica_herrera).
lugares(cologio_salesiano_santa_cecilia).
lugares(colegio_champagnat).
lugares(colegio_belen).

%lugares centros de salud
lugares(clinica_inmaculada_concepcion).
lugares(clinica_colinas).
lugares(hospital_casa_salud).
lugares(policlinico_magisterial).
lugares(cruz_roja_santa_tecla).

%lugares centros cormerciales
lugares(plaza_cafetalon).

%lugares restaurantes
lugares(piccola_cafe).
lugares(teklebab).
lugares(freakie).
lugares(teclena).
lugares(pollolandia).
lugares(pizzeria_italia).

%lugares varios
lugares(gimnasio_adolfo_pineda).
lugares(alcaldia_municipal).
lugares(phonecloud_sv).
lugares(hogar_ninos_adalberto_guirola).
lugares(mega_tazumal).
lugares(parroquia_carmen).
lugares(teclena).
lugares(club_tecleno).
lugares(dui_centro).
lugares(surco).
lugares(hotel_don_moncho).
lugares(gio_taller).
lugares(club_tecleno).
lugares(libreria_aranda).

%-----------------------------------------

%Conexiones

conexiones(sexta_av_norte_3,quinta_calle_poniente_2).
conexiones(sexta_av_norte_3,sexta_av_norte_2).

conexiones(quinta_calle_poniente_1,sexta_av_norte_2).
conexiones(quinta_calle_poniente_1,quinta_calle_poniente_2).

conexiones(quinta_calle_poniente_2,cuarta_av_norte_4).
conexiones(quinta_calle_poniente_2,quinta_calle_poniente_3).

conexiones(cuarta_av_norte_4,septima_calle_poniente_1).

conexiones(septima_calle_poniente_1,sexta_av_norte_3).

conexiones(segunda_av_norte_4,quinta_calle_oriente_1).
conexiones(segunda_av_norte_4,segunda_av_norte_3).

conexiones(av_dr_manuel_gallardo_5,septima_calle_poniente_3).

conexiones(septima_calle_poniente_3,segunda_av_norte_4).
conexiones(septima_calle_poniente_3,septima_calle_poniente_2).

conexiones(quinta_av_norte_4,quinta_calle_oriente_5).
conexiones(quinta_av_norte_4,quinta_av_norte_3).

conexiones(septima_av_norte_4,septima_calle_oriente_2).

conexiones(septima_calle_oriente_2, quinta_av_norte_4).

conexiones(septima_calle_oriente_1,septima_calle_oriente_2).

conexiones(once_av_norte,septima_calle_oriente_1).

conexiones(quinta_calle_oriente_3,quinta_calle_oriente_1).
conexiones(quinta_calle_oriente_3,segunda_av_norte_3).

conexiones(quinta_calle_oriente_1,av_dr_manuel_gallardo_5).
conexiones(quinta_calle_oriente_1,quinta_calle_oriente_2).

conexiones(quinta_calle_oriente_2,primera_av_norte_2).
conexiones(quinta_calle_oriente_2,quinta_calle_oriente_3).

conexiones(quinta_calle_oriente_3,quinta_calle_oriente_4).

conexiones(quinta_calle_oriente_4,quinta_av_norte_3).
conexiones(quinta_calle_oriente_4,quinta_calle_oriente_5).

conexiones(quinta_calle_oriente_5,septima_av_norte_4).
conexiones(quinta_calle_oriente_5,quinta_calle_oriente_6).

conexiones(quinta_calle_oriente_6,once_av_norte).

conexiones(tercera_calle_poniente_2,sexta_av_norte_1).

conexiones(tercera_calle_poniente_3,tercera_calle_poniente_2).
conexiones(tercera_calle_poniente_3,cuarta_av_norte_3).

conexiones(tercera_calle_poniente_4,tercera_calle_poniente_3).
conexiones(tercera_calle_poniente_4,segunda_av_norte_2).

conexiones(tercera_calle_oriente_1,tercera_calle_poniente_4).
conexiones(tercera_calle_oriente_1,av_dr_manuel_gallardo_4).

conexiones(tercera_calle_oriente_2,tercera_calle_oriente_1).
conexiones(tercera_calle_oriente_2,primera_av_norte_1).

conexiones(tercera_calle_oriente_3,tercera_av_norte_3).
conexiones(tercera_calle_oriente_3,tercera_calle_oriente_2).

conexiones(tercera_calle_oriente_4,tercera_calle_oriente_3).
conexiones(tercera_calle_oriente_4,quinta_av_norte_2).

conexiones(sexta_av_norte_2,sexta_av_norte_1).

conexiones(cuarta_av_norte_3,cuarta_av_norte_4).
conexiones(cuarta_av_norte_3,quinta_calle_poniente_3).

conexiones(segunda_av_norte_3,tercera_calle_poniente_3).
conexiones(segunda_av_norte_3,segunda_av_norte_2).

conexiones(av_dr_manuel_gallardo_4,av_dr_manuel_gallardo_5).
conexiones(av_dr_manuel_gallardo_4,quinta_calle_oriente_1).

conexiones(primera_av_norte_2,primera_av_norte_1).
conexiones(primera_av_norte_2,tercera_calle_oriente_2).

conexiones(tercera_av_norte_3, quinta_calle_oriente_4).

conexiones(quinta_av_norte_3,quinta_calle_oriente_3).
conexiones(quinta_av_norte_3,quinta_av_norte_2).

conexiones(septima_av_norte_3,septima_av_norte_4).
conexiones(septima_av_norte_3,quinta_calle_oriente_6).


%-------------------------------------------

conexiones(calle_daniel_hernandez_1, sexta_av_sur_1).
conexiones(calle_daniel_hernandez_1, calle_daniel_hernandez_2).

conexiones(calle_daniel_hernandez_2, cuarta_av_norte_1).
conexiones(calle_daniel_hernandez_2, calle_daniel_hernandez_3).

conexiones(cuarta_av_sur_1, cuarta_av_norte_1).
conexiones(cuarta_av_sur_1, calle_daniel_hernandez_3).

conexiones(calle_daniel_hernandez_3, segunda_av_sur_1).
conexiones(calle_daniel_hernandez_3, calle_daniel_hernandez_4).

conexiones(calle_daniel_hernandez_4, calle_jose_ciriaco_lopez_1).
conexiones(calle_daniel_hernandez_4, av_dr_manuel_gallardo_2).

conexiones(av_dr_manuel_gallardo_1, calle_jose_ciriaco_lopez_1).
conexiones(av_dr_manuel_gallardo_1, av_dr_manuel_gallardo_2).

conexiones(calle_jose_ciriaco_lopez_1, primera_av_sur_1).
conexiones(calle_jose_ciriaco_lopez_1, calle_jose_ciriaco_lopez_2).

conexiones(calle_jose_ciriaco_lopez_2, tercera_av_norte_1).
conexiones(calle_jose_ciriaco_lopez_2, calle_jose_ciriaco_lopez_3).

conexiones(tercera_av_sur_1, calle_jose_ciriaco_lopez_3).
conexiones(tercera_av_sur_1, tercera_av_norte_1).

conexiones(calle_jose_ciriaco_lopez_3, calle_jose_ciriaco_lopez_4).
conexiones(calle_jose_ciriaco_lopez_3, quinta_av_sur_1).

conexiones(calle_jose_ciriaco_lopez_4, septima_av_norte_1).

conexiones(septima_av_sur_1, septima_av_norte_1).

conexiones(sexta_av_sur_2, sexta_av_sur_1).
conexiones(sexta_av_sur_2, calle_daniel_hernandez_2).

conexiones(paseo_el_carmen_1, sexta_av_sur_2).
conexiones(paseo_el_carmen_1, paseo_el_carmen_2).

conexiones(paseo_el_carmen_2, cuarta_av_norte_2).
conexiones(paseo_el_carmen_2, paseo_el_carmen_3).

conexiones(cuarta_av_norte_1, cuarta_av_norte_2).
conexiones(cuarta_av_norte_1, paseo_el_carmen_3).

conexiones(paseo_el_carmen_3, segunda_av_norte_1).
conexiones(paseo_el_carmen_3, paseo_el_carmen_4).

conexiones(segunda_av_norte_1, calle_daniel_hernandez_4).
conexiones(segunda_av_norte_1, segunda_av_sur_1).

conexiones(paseo_el_carmen_4, av_dr_manuel_gallardo_3).
conexiones(paseo_el_carmen_4, paseo_el_carmen_5).

conexiones(av_dr_manuel_gallardo_2, av_dr_manuel_gallardo_3).
conexiones(av_dr_manuel_gallardo_2, paseo_el_carmen_5).

conexiones(paseo_el_carmen_5, paseo_el_carmen_6).
conexiones(paseo_el_carmen_5, primera_av_sur_2).

conexiones(primera_av_sur_2, calle_jose_ciriaco_lopez_2).
conexiones(primera_av_sur_2, primera_av_sur_1).

conexiones(paseo_el_carmen_6, tercera_av_norte_2).
conexiones(paseo_el_carmen_6, paseo_el_carmen_7).

conexiones(tercera_av_norte_1, tercera_av_norte_2).
conexiones(tercera_av_norte_1, paseo_el_carmen_7).

conexiones(paseo_el_carmen_7, quinta_av_norte_1).
conexiones(paseo_el_carmen_7, paseo_el_carmen_8).

conexiones(quinta_av_norte_1, calle_jose_ciriaco_lopez_4).
conexiones(quinta_av_norte_1, quinta_av_sur_1).

conexiones(paseo_el_carmen_8, septima_av_norte_2).

conexiones(septima_av_norte_1, septima_av_norte_2).

conexiones(panamericana_1, septima_av_sur_1).

conexiones(sexta_av_norte_1, sexta_av_sur_2).
conexiones(sexta_av_norte_1, paseo_el_carmen_2).

conexiones(cuarta_av_norte_2, tercera_calle_poniente_3).
conexiones(cuarta_av_norte_2, cuarta_av_norte_3).

conexiones(segunda_av_norte_2, segunda_av_norte_1).
conexiones(segunda_av_norte_2, paseo_el_carmen_4).

conexiones(av_dr_manuel_gallardo_3, av_dr_manuel_gallardo_4).
conexiones(av_dr_manuel_gallardo_3, tercera_calle_oriente_1).

conexiones(primera_av_norte_1, paseo_el_carmen_6).
conexiones(primera_av_norte_1, primera_av_sur_2).

conexiones(tercera_av_norte_2, tercera_calle_oriente_2).
conexiones(tercera_av_norte_2, tercera_av_norte_3).

conexiones(quinta_av_norte_2, paseo_el_carmen_8).
conexiones(quinta_av_norte_2, quinta_av_norte_1).

conexiones(septima_av_norte_2, tercera_calle_oriente_4).
conexiones(septima_av_norte_2, septima_av_norte_3).

%-------------------------------------------------------------------

%Conexiones_lugares_calles

conexiones(parque_daniel_hernandez, calle_daniel_hernandez_4).
conexiones(calle_daniel_hernandez_4,parque_daniel_hernandez).

conexiones(parque_san_martin, calle_jose_ciriaco_lopez_3).
conexiones(calle_jose_ciriaco_lopez_3, parque_san_martin).

conexiones(parque_deportivo_el_cafetalon,septima_av_norte_2).
conexiones(septima_av_norte_2,parque_deportivo_el_cafetalon).

conexiones(escuela_monica_herrera,av_dr_manuel_gallardo_4).
conexiones(av_dr_manuel_gallardo_4,escuela_monica_herrera).

conexiones(cologio_salesiano_santa_cecilia,quinta_calle_oriente_2).
conexiones(quinta_calle_oriente_2,cologio_salesiano_santa_cecilia).

conexiones(colegio_champagnat,quinta_calle_oriente_6).
conexiones(quinta_calle_oriente_6,colegio_champagnat).

conexiones(colegio_belen, tercera_av_norte_3).
conexiones(tercera_av_norte_3,colegio_belen).

conexiones(clinica_inmaculada_concepcion,cuarta_av_norte_1).
conexiones(cuarta_av_norte_1,clinica_inmaculada_concepcion).


conexiones(clinica_colinas,sexta_av_norte_3).
conexiones(sexta_av_norte_3,clinica_colinas).

conexiones(hospital_casa_salud,cuarta_av_norte_3).
conexiones(cuarta_av_norte_3,hospital_casa_salud).

conexiones(policlinico_magisterial,cuarta_av_norte_4).
conexiones(cuarta_av_norte_4,policlinico_magisterial).

conexiones(cruz_roja_santa_tecla, quinta_calle_oriente_6).
conexiones(quinta_calle_oriente_6, cruz_roja_santa_tecla).

conexiones(plaza_cafetalon,septima_av_norte_2).
conexiones(septima_av_norte_2,plaza_cafetalon).

conexiones(piccola_cafe,paseo_el_carmen_2).
conexiones(paseo_el_carmen_2,piccola_cafe).

conexiones(teklebab,quinta_av_norte_2).
conexiones(quinta_av_norte_2,teklebab).

conexiones(freakie,once_av_norte).
conexiones(once_av_norte,freakie).

conexiones(teclena, primera_av_sur_1).
conexiones(primera_av_sur_1, teclena).

conexiones(pollolandia, primera_av_sur_2).
conexiones(primera_av_sur_2, pollolandia).

conexiones(gimnasio_adolfo_pineda, sexta_av_sur_1).
conexiones(sexta_av_sur_1, gimnasio_adolfo_pineda).

conexiones(alcaldia_municipal, segunda_av_norte_2).
conexiones(segunda_av_norte_2, alcaldia_municipal).

conexiones(phonecloud_sv, septima_calle_poniente_3).
conexiones(septima_calle_poniente_3, phonecloud_sv).

conexiones(hogar_ninos_adalberto_guirola, septima_av_norte_1).
conexiones(septima_av_norte_1, hogar_ninos_adalberto_guirola).

conexiones(parroquia_carmen, paseo_el_carmen_4).
conexiones(paseo_el_carmen_4, parroquia_carmen).

conexiones(club_tecleno, quinta_calle_oriente_4).
conexiones(quinta_calle_oriente_4, club_tecleno).

conexiones(dui_centro, segunda_av_sur_1).
conexiones(segunda_av_sur_1, dui_centro).

conexiones(hotel_don_moncho, primera_av_norte_1).
conexiones(primera_av_norte_1, hotel_don_moncho).

conexiones(gio_taller, calle_jose_ciriaco_lopez_4).
conexiones(calle_jose_ciriaco_lopez_4, gio_taller).

conexiones(libreria_aranda, septima_av_norte_2).
conexiones(septima_av_norte_2, libreria_aranda).

conexiones(pizzeria_italia, tercera_calle_poniente_3).
conexiones(tercera_calle_poniente_3, pizzeria_italia).

%---------------------------------------------------------

ir_hacia(X, Y):-
    busca_camino([X], Y, Ruta),
    reverse(Ruta, RutaInvertida),
    imprimir_ruta(RutaInvertida).

busca_camino([X | RestoRuta], Y, [Y, X | RestoRuta]):-
    conexiones(X, Y).

busca_camino([X | RestoRuta], Y, Ruta):-
    conexiones(X, Z),
    not(member(Z, [X | RestoRuta])),
    busca_camino([Z, X | RestoRuta], Y, Ruta).

imprimir_ruta([]).

imprimir_ruta([X | RestoRuta]):-
    writeln(X),
    imprimir_ruta(RestoRuta).
